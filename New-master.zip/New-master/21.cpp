/*
	NEWPTIT
*/
#include<bits/stdc++.h>
#define ll long long
#define MOD 1000000000000007
/*

| 0 1 0 |	 | f1 |	  | f2           |
| 0 0 1 |  . | f2 | = | f3			 |
| 1 1 1 |	 | f3 |	  | f1 + f2 + f3 |

*/
using namespace std;
struct maTrix{
	ll m[0]
};
int main(){

	return 0;
}

